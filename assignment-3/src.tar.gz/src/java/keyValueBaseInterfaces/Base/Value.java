package keyValueBaseInterfaces;

import java.io.Serializable;

public interface Value extends Serializable
{
	public String toString();
}
