package keyValueBaseInterfaces;

public abstract class Predicate<T> {
	public abstract boolean evaluate(T input);
}
