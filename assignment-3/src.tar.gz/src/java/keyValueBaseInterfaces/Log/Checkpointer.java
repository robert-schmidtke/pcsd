package keyValueBaseInterfaces;

public interface Checkpointer extends Runnable {
}
