﻿using System;
using System.Collections.Generic;
using KeyValueBase.Interfaces;

namespace KeyValueBase
{
  public class ValueListImpl : IValueList<string>
  {
    public void Add(string item)
    {
      throw new NotImplementedException();
    }

    public void Remove(string item)
    {
      throw new NotImplementedException();
    }

    public void Merge(IValueList<string> list)
    {
      throw new NotImplementedException();
    }

    public IList<string> ToList()
    {
      throw new NotImplementedException();
    }

    public bool Equals(IValue other)
    {
      throw new NotImplementedException();
    }

    public IEnumerator<string> GetEnumerator()
    {
      throw new NotImplementedException();
    }

    System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
    {
      throw new NotImplementedException();
    }
  }
}
