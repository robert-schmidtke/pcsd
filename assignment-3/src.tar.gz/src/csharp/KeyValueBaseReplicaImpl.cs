﻿using System;
using System.Collections.Generic;
using KeyValueBase.Interfaces;

namespace KeyValueBase
{
  public class KeyValueBaseReplicaImpl : IKeyValueBaseReplica<KeyImpl, ValueListImpl>
  {
    public void Init(string serverFilename)
    {
      throw new NotImplementedException();
    }

    public KeyValuePair<TimestampLog, ValueListImpl> Read(KeyImpl k)
    {
      throw new NotImplementedException();
    }

    public KeyValuePair<TimestampLog, IEnumerable<ValueListImpl>> Scan(KeyImpl begin, KeyImpl end, IPredicate<ValueListImpl> p)
    {
      throw new NotImplementedException();
    }

    public KeyValuePair<TimestampLog, IEnumerable<ValueListImpl>> AtomicScan(KeyImpl begin, KeyImpl end, IPredicate<ValueListImpl> p)
    {
      throw new NotImplementedException();
    }
  }
}
