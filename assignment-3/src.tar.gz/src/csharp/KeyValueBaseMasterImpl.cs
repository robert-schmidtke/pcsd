﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KeyValueBase.Interfaces;

namespace KeyValueBase
{
  public class KeyValueBaseMasterImpl : KeyValueBaseReplicaImpl, IKeyValueBaseMaster<KeyImpl, ValueListImpl>
  {
    public void Insert(KeyImpl key, ValueListImpl value)
    {
      throw new NotImplementedException();
    }

    public void Update(KeyImpl key, ValueListImpl newValue)
    {
      throw new NotImplementedException();
    }

    public void Delete(KeyImpl key)
    {
      throw new NotImplementedException();
    }

    public void BulkPut(IEnumerable<KeyValuePair<KeyImpl, ValueListImpl>> pairs)
    {
      throw new NotImplementedException();
    }

    public void Configure(Configuration conf)
    {
      throw new NotImplementedException();
    }
  }
}
