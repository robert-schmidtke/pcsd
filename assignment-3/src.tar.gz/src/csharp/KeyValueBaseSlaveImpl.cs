﻿using System;
using KeyValueBase.Interfaces;

namespace KeyValueBase
{
  public class KeyValueBaseSlaveImpl : KeyValueBaseReplicaImpl, IKeyValueBaseSlave<KeyImpl, ValueListImpl>
  {
    public void LogApply(LogRecord record)
    {
      throw new NotImplementedException();
    }
  }
}
