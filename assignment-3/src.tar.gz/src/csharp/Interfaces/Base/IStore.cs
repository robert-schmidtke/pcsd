﻿namespace KeyValueBase.Interfaces
{
  public interface IStore
  {
    long Size { get; }
    byte[] Read(long position, int length);
    void Write(long position, byte[] value);
  }
}
