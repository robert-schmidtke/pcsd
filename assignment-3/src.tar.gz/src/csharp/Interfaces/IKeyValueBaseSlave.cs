﻿using System.Collections.Generic;

namespace KeyValueBase.Interfaces
{
  public interface IKeyValueBaseSlave<K, V> : IKeyValueBaseReplica<K, V>
    where K : IKey<K>
    where V : IValue
  {
    /// <summary>
    /// Applies a log record
    /// </summary>
    /// <param name="record">a log record</param>
    void LogApply(LogRecord record);
  }
}
