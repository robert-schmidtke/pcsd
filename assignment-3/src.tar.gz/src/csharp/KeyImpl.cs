﻿using System;
using KeyValueBase.Interfaces;

namespace KeyValueBase
{
  public class KeyImpl : IKey<KeyImpl>
  {
    public int CompareTo(KeyImpl other)
    {
      throw new NotImplementedException();
    }
  }
}
