﻿using System.Runtime.Serialization;

namespace KeyValueBase.Faults
{
  [DataContract]
  public class ServiceAlreadyConfiguredFault
  {
    [DataMember(Name = "Message")]
    private string message;

    public ServiceAlreadyConfiguredFault()
      : this("The service has already been configured")
    {
    }

    public ServiceAlreadyConfiguredFault(string message)
    {
      this.message = message;
    }

    public string Message
    {
      get { return this.message; }
    }
  }
}
