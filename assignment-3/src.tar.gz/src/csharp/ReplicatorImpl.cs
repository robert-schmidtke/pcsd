﻿using System;
using KeyValueBase.Interfaces;

namespace KeyValueBase
{
  public class ReplicatorImpl : IReplicator
  {
    public IAsyncResult BeginMakeStable(LogRecord record, AsyncCallback callback, object asyncState)
    {
      throw new NotImplementedException();
    }

    public void EndMakeStable(IAsyncResult asyncResult)
    {
      throw new NotImplementedException();
    }
  }
}
