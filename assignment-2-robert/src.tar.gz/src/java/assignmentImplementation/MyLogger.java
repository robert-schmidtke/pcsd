package assignmentImplementation;

import java.util.concurrent.Future;

import keyValueBaseInterfaces.LogRecord;
import keyValueBaseInterfaces.Logger;

public class MyLogger implements Logger {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Future<?> logRequest(LogRecord record) {
		// TODO Auto-generated method stub
		return null;
	}

}
