package assignmentImplementation;

import keyValueBaseInterfaces.KeyValueBaseLog;

public class MyKeyValueBaseLog implements KeyValueBaseLog<KeyImpl,ValueListImpl> {

	@Override
	public void quiesce() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub
		
	}
	
}
