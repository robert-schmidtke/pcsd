package assignmentImplementation;

import keyValueBaseInterfaces.Checkpointer;

public class MyCheckpointer implements Checkpointer {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
