﻿using System;

namespace KeyValueBase.Interfaces
{
  public enum OperationType
  {
    Update,
    Insert,
    Delete,
    Checkpoint
  }

  public class LogRecord
  {
    private OperationType operationType;
    private object[] parameters;

    public LogRecord(OperationType operationType, object[] parameters)
    {
      this.operationType = operationType;
      this.parameters = parameters;
    }

    public OperationType OperationType
    {
      get { return this.operationType; }
    }

    public object[] Parameters
    {
      get { return this.parameters; }
    }
  }
}
