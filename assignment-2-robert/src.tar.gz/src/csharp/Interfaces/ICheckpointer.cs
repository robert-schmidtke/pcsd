﻿namespace KeyValueBase.Interfaces
{
  public interface ICheckpointer
  {
    void CreateCheckpoint();
  }
}
