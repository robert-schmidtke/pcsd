package assignmentImplementation;

import keyValueBaseInterfaces.Key;

public class KeyImpl implements Key<KeyImpl>
{

	@Override
	public int compareTo(KeyImpl arg0) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

}
