package assignmentImplementation;

import java.io.IOException;
import keyValueBaseInterfaces.ValueSerializer;

public class ValueSerializerImpl implements ValueSerializer<ValueListImpl> {

	@Override
	public ValueListImpl fromByteArray(byte[] array) throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public byte[] toByteArray(ValueListImpl v) throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

}
