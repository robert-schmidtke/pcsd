package assignmentImplementation;

import java.util.Iterator;
import java.util.List;

import keyValueBaseInterfaces.ValueList;

@SuppressWarnings("serial")
public class ValueListImpl implements ValueList<ValueImpl>{
	
	@Override
	public void add(ValueImpl v) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remove(ValueImpl v) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void merge(ValueList<ValueImpl> v) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<ValueImpl> toList() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public Iterator<ValueImpl> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

}
