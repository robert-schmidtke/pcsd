package assignmentImplementation;

import keyValueBaseInterfaces.Store;

public class StoreImpl implements Store
{

	@Override
	public byte[] read(Long position, int length) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void write(Long position, byte[] value) {
		// TODO Auto-generated method stub
		
	}
	
}
