package assignmentImplementation;

import keyValueBaseInterfaces.Value;

@SuppressWarnings("serial")
public class ValueImpl implements Value
{

	public String toString() {
		return null;
	}
	
}

