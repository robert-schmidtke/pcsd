﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KeyValueBase.Interfaces;

namespace KeyValueBase
{
  public class KeyImpl : IKey<KeyImpl>
  {
    public int CompareTo(KeyImpl other)
    {
      throw new NotImplementedException();
    }
  }
}
