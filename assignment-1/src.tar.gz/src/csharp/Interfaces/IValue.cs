﻿using System;

namespace KeyValueBase.Interfaces
{
  public interface IValue : IEquatable<IValue>
  {
  }
}
