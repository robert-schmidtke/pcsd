﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KeyValueBase.Interfaces;

namespace KeyValueBase
{
  public class IndexImpl : IIndex<KeyImpl, ValueListImpl>
  {
    public void Insert(KeyImpl key, ValueListImpl value)
    {
      throw new NotImplementedException();
    }

    public void Remove(KeyImpl key)
    {
      throw new NotImplementedException();
    }

    public void Update(KeyImpl key, ValueListImpl newValue)
    {
      throw new NotImplementedException();
    }

    public ValueListImpl Get(KeyImpl key)
    {
      throw new NotImplementedException();
    }

    public IEnumerable<ValueListImpl> Scan(KeyImpl begin, KeyImpl end)
    {
      throw new NotImplementedException();
    }

    public IEnumerable<ValueListImpl> AtomicScan(KeyImpl begin, KeyImpl end)
    {
      throw new NotImplementedException();
    }

    public void BulkPut(IEnumerable<KeyValuePair<KeyImpl, ValueListImpl>> pairs)
    {
      throw new NotImplementedException();
    }
  }
}
