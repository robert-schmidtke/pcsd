﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KeyValueBase.Interfaces;

namespace KeyValueBase
{
  public class ValueSerializerImpl : IValueSerializer<ValueImpl>
  {
    public ValueImpl FromByteArray(byte[] array)
    {
      throw new NotImplementedException();
    }

    public byte[] ToByteArray(ValueImpl v)
    {
      throw new NotImplementedException();
    }
  }
}
