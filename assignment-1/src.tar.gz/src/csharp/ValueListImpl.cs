﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KeyValueBase.Interfaces;

namespace KeyValueBase
{
  public class ValueListImpl : IValueList<ValueImpl>
  {
    public void Add(ValueImpl item)
    {
      throw new NotImplementedException();
    }

    public void Remove(ValueImpl item)
    {
      throw new NotImplementedException();
    }

    public void Merge(IValueList<ValueImpl> list)
    {
      throw new NotImplementedException();
    }

    public IList<ValueImpl> ToList()
    {
      throw new NotImplementedException();
    }

    public bool Equals(IValue other)
    {
      throw new NotImplementedException();
    }

    public IEnumerator<ValueImpl> GetEnumerator()
    {
      throw new NotImplementedException();
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
      throw new NotImplementedException();
    }
  }
}
