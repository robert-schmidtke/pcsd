﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KeyValueBase.Interfaces;

namespace KeyValueBase
{
  public class StoreImpl : IStore
  {
    public byte[] Read(long position, int length)
    {
      throw new NotImplementedException();
    }

    public void Write(long position, byte[] value)
    {
      throw new NotImplementedException();
    }
  }
}
