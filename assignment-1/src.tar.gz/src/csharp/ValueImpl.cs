﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KeyValueBase.Interfaces;

namespace KeyValueBase
{
  public class ValueImpl : IValue
  {
    public bool Equals(IValue other)
    {
      throw new NotImplementedException();
    }
  }
}
